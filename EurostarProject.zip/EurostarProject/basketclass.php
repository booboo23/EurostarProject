<?php
class basket {
               
    private $DB;
    
	public function __construct($DB) {
             
		if (! isset ( $_SESSION )) {
			session_start ();
		}
		
		if (! isset ( $_SESSION ['basket'] )) {
			$_SESSION ['basket'] = array ();
		}
                
                                    $this->DB = $DB;
                                    
                              
                                    
                                    
	$basket= filter_input(INPUT_POST,'basket', FILTER_DEFAULT);
             $quantity=  filter_input(INPUT_POST,'quantity', FILTER_DEFAULT);
              if(isset($basket,$quantity)){
                   $this->recalc();
               }
        }
        
        public function recalc(){                     
          $basket= filter_input(INPUT_POST,'basket', FILTER_DEFAULT);
          $quantity=  filter_input(INPUT_POST,'quantity', FILTER_DEFAULT);              
            foreach ($_SESSION['basket'] as $id => $quantity){
            if(isset($basket,$quantity,$id)){               
                 $_SESSION['basket'][$id] = [$basket][$quantity][$id] ;
                 }
               
            }            
       }
        
        
        // dans le cas d'une vue sur le nombre de produit global du panier
                        public function count() {
                         return    array_sum($_SESSION['basket']);
                            
                        }
        
        
        
        
                                                    public function total() {

                                                        $total=0;
                                                         $ids=array_keys($_SESSION['basket']);
                                                 if(empty($ids)){
                                                     $product = array();
                                                 }else {
                                                      $product = $this->DB->query('SELECT id, price FROM product WHERE id IN ('.implode(',',$ids).')'); 
                                                 }                                          
                                                        foreach($product as $Product) {
                                                          $total += $Product->price * $_SESSION['basket'][$Product->id];
                                                    }
                                                    return $total;
                                                    }
               
               
               
        
                                                                        public function add($id) {
                                                                                            if(isset($_SESSION['basket'][$id])){
                                                                                            $_SESSION ['basket'] [$id] ++;

                                                                                            }else{
                                                                                            $_SESSION['basket'][$id]=1;
                                                                                            }
                                                                        }



                                                                                                public function del($id){

                                                                                                            unset($_SESSION ['basket'] [$id]);

                                                                                                }
                                        }