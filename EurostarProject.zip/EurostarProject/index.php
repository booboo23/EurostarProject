 
<?php require 'header.php'; ?>






<div class="slider"></div>


<div class="basket">
    <span id="choice"><center>Choice your pleasure!</center></span>
        
    <a class="logobasketindex" href="basket.php"><img  src="img/logobasket.jpg"></a>
    
        <table id="totalindex"><thead>
            
                        <tr><td>items</td>
                        
                            <td>total</td></tr>
            </thead>
            <tbody>
                <tr>
                    <td id="items"><?php echo $basket->count();?></td>                               
                    <td id="totaljs"><?php echo number_format($basket->total() ,2, ',','') ;?></td>
                </tr>
            </tbody>
        </table>
        
           
        

       <?php $product =  $DB->query('SELECT * FROM product'); ?>

       <?php  foreach ( $product as $Product ) : ?>
    <div id="choicep"><span id="basketvisual"></span>
		<article>
			<img src="img/<?php echo $Product->id;?>.jpg"
				title="<?php echo $Product->name_product;?>"</img> <br></br>
			<center>
				<span id="description"><?php echo $Product->name_product;  ?>: <?php echo number_format($Product->price,2,',','');?>£</span>
				&nbsp;&nbsp;<a class="addbasket"
					href="adbasket.php?id=<?php echo $Product->id; ?>"><img
					src="img/logo_panier.png " alt="add your product" /></a>
			</center>
		</article>
	</div>
        <?php endforeach ?>
            
      </div>

<?php require 'footer.php'; ?>
<?php

