<?php
require '_header.php';
$json = array('error' => true);

$id = filter_input(INPUT_GET,'id', FILTER_DEFAULT);

if(isset($id))   {
    
	$Product = $DB->query ( 'SELECT id FROM product WHERE id=:id'
                
                    , array('id' => filter_input(INPUT_GET,'id', FILTER_DEFAULT)
                
	) );

	if (empty ( $Product )) {
		$json['message'] =  "This product don't exist";
        
                     }
                                    $basket->add ($Product[0]->id);
                                    $json['error']= false;
                                    $json['total'] = $basket->total();
                                    $json['count'] = $basket->count();
                                    $json['message']='The product has been added in your basket';
                    } else {
                               $json['message']="You must add a product in your basket";
                             }
                    
                      echo json_encode($json);
     
                   
 

