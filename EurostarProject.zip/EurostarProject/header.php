<?php
require '_header.php';
?>


<html>
<head>
<meta charset="UTF-8">
<meta name="" content="">
<meta name="" lang="fr" >
<title>My little Bakery</title>
<link rel="stylesheet" href="css/index.css">
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.min.js" rel="stylesheet"></script>
</head>


<body>




	<div id="page">

		<header class="htpage">
			<img class="displayed" src="img/logo.png" alt="Logo of booboo" />.


			<nav>
				<ul>
					<li><a href="basket.php">Basket</a></li>
					<li><a href="#">Contacts</a></li>
				</ul>
			</nav>

		</header>