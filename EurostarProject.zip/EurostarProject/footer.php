












<footer>
	<br>
	<span><center>2016 © Copyright My little Bakery.</center></span> <span
		id="myname"><center>Sébastien MARIE-ANGELIQUE</center>
		</br>

</footer>

</div>
<script
			 
<script type="text/javascript" src="jquery/jquery.js"></script>
<script type="text/javascript" src="js/app.js"></script>

</body>
