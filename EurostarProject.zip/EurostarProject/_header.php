<?php
require 'dbclass.php';
require 'basketclass.php';
$DB = new DB ();
$basket = new basket ($DB);

