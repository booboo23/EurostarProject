<?php require '_header.php';?>
<?php 
$del = filter_input(INPUT_GET,'del', FILTER_DEFAULT);
if (isset($del)){
    $basket->del($del);  
}?>

<html>
<head>
<meta charset="UTF-8">
<meta name="" content="">
<meta name="" lang="fr" content="">
<title>My little Bakery customer</title>
<link rel="stylesheet" href="css/basket.css">

<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="bootstrap/js/jquery.js"></script>
<script src="bootstrap/js/bootstrap.min.js" rel="stylesheet"></script>
</head>


<body>
    
    
    
    
                <div id = "headerb">
                    
                  
                    <img class="logo" src="img/logo.png" alt="enterprise logo"/>
                    <span>Dear customer  welcome in your basket ! </span>
                    <img class="logobasket" src ="img/logobasket.jpg" alt="panier logo "/>
                    
                     
                </div>
    
    
   
    
        
    <div id="customerb">
        
        <form method ="post" action="basket.php">
        
        <table id="mybasket">  
          
            <thead>
                <tr class="trown">
                    <td><h3>Product</h3></td>
                    <td><h3>Price</h3></td>
                    <td><h3>Quantity</h3></td>
                    <td><h3>Subtotal</h3></td>
                    <td><h3>Actions</h3></td>
                 </tr>
            </thead>    
            
            <tbody>  <?php 
            $ids=array_keys($_SESSION['basket']);
            if(empty($ids)){
                $product = array();
            }else {
                 $product=$DB->query('SELECT * FROM product WHERE id IN ('.implode(',',$ids).')'); 
            }
            
           
            foreach ($product as $Product):
            
                 ?>
                <tr>
                    <td><div id="data"><img src="img/<?php echo $Product->id; ?>.jpg"><?php echo $Product->name_product; ?></div></td>
                    <td><div id="data"><?php echo number_format($Product->price,2,',','');?>£</div></td>
                    <td><div id="data"><span id="count"><input type ="text" name="basket[quantity][<?php echo $Product->id; ?>]" value="<?php echo $_SESSION['basket'][$Product->id];?>"</span></div></td>
                    <td><div id="data"><?php echo number_format($Product->price * 1.196,2,',',''); ?>£</div></td>
                    <td><div id="delete"><a href="basket.php?del=<?php echo $Product->id;?>"><img  src ="img/delete.png"/></a></div></td>
                </tr>
                     
                 <?php endforeach; ?>
            
                <tr>
                    <td colspan="5" class="tdrow"><div id="lastrow"><div><a href="index.php"><img class ="home"src="img/logohome.jpg"/></a></div><div id="calcul"><input type="submit" value="recalculate"></div><div id="totalscan">Total:&nbsp;<span id="total"><span id="addtotal"><?php echo  number_format($basket->total() * 1.196,2, ',',''); ?></span>£</span></div></div></td>
                </tr>
                    
            </tbody>
     
        </table>
     </form>
    </div>
   
</body>
   
<?php require 'footer.php' ;